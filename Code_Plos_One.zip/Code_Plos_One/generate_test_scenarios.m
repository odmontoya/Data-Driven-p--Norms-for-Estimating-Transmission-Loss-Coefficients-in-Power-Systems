function out = generate_test_scenarios(CaseName, opts)
%GENERATE_TEST_SCENARIOS Generate convergent PF scenarios for evaluation/testing.
%
% This is analogous to the training scenario generator, but typically uses:
%   - different RNG seed
%   - different number of scenarios M
%   - different save filename pattern

    if nargin < 2, opts = struct(); end

    % ---- Defaults ----
    def.seed = 2026;
    def.M = 1000;                    % typical test set size
    def.saveFile = true;
    def.savePattern = 'TestScenario_%s.mat';

    % Reuse the same PF/randomization defaults as training
    def.pfAlg = 'NR';
    def.pfMaxIt = 50;
    def.verbose = 0;

    def.loadScaleMin = 0.8;
    def.loadScaleMax = 1.2;
    def.genPertMin   = 0.7;
    def.genPertMax   = 1.1;

    def.minFracPmax  = 0.02;
    def.seedFracPmax = 0.05;
    def.pmaxMargin   = 0.98;

    def.maxAttempts  = 50;

    opts = set_default_opts(opts, def);

    % Call the training generator internally but saving to test pattern
    tmpOpts = opts;
    tmpOpts.savePattern = opts.savePattern;

    out = generate_training_scenarios(CaseName, tmpOpts);

    % Rename field for clarity in the returned struct (optional)
    out.kind = 'test';
end

function opts = set_default_opts(opts, def)
    fn = fieldnames(def);
    for i = 1:numel(fn)
        if ~isfield(opts, fn{i})
            opts.(fn{i}) = def.(fn{i});
        end
    end
end
