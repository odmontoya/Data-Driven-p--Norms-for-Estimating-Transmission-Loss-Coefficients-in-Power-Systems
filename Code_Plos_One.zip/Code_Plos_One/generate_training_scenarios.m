function out = generate_training_scenarios(CaseName, opts)
%GENERATE_TRAINING_SCENARIOS Generate convergent PF scenarios for training.
%
% Produces PL (Mx1) and Pgm (NgxM) by randomizing loads and generator
% setpoints around a convergent base PF. Only convergent scenarios are kept.
%
% Requires MATPOWER: loadcase, runpf, mpoption.

    if nargin < 2, opts = struct(); end

    % ---- Defaults ----
    def.seed = 1234;
    def.pfAlg = 'NR';
    def.pfMaxIt = 50;
    def.verbose = 0;

    def.loadScaleMin = 0.8;
    def.loadScaleMax = 1.2;
    def.genPertMin   = 0.7;
    def.genPertMax   = 1.1;

    def.minFracPmax  = 0.02;
    def.seedFracPmax = 0.05;
    def.pmaxMargin   = 0.98;

    def.maxAttempts  = 50;
    def.M            = NaN;

    def.saveFile     = true;
    def.savePattern  = "DataTrain_%s.mat";

    opts = set_default_opts(opts, def);

    rng(opts.seed);

    % Load case and PF options
    mpc0  = loadcase(CaseName);
    mpopt = mpoption('pf.alg', opts.pfAlg, 'pf.nr.max_it', opts.pfMaxIt, 'verbose', opts.verbose);

    % Base-case PF
    [res0, success0] = runpf(mpc0, mpopt);
    if ~success0
        error('Base-case PF did not converge for %s. Fix the case first.', CaseName);
    end

    Ng    = size(mpc0.gen, 1);
    Dem0  = mpc0.bus(:, 3);
    Qdem0 = mpc0.bus(:, 4);

    Pg0  = res0.gen(:, 2);
    Pmax = mpc0.gen(:, 9);
    Pmin = mpc0.gen(:,10);

    Pd0      = sum(Dem0);
    Ploss0   = sum(res0.gen(:,2)) - Pd0;
    loss_fac = Ploss0 / Pd0;

    % Avoid zero base generation
    Pg_base = Pg0;
    idx_zero = (Pg_base == 0);
    Pg_base(idx_zero) = opts.seedFracPmax * Pmax(idx_zero);
    Pg_base = max(Pg_base, opts.minFracPmax * Pmax);

    % Number of scenarios
    if isnan(opts.M)
        M = Ng*(Ng+3)/2 + 1;
    else
        M = opts.M;
    end

    PL  = zeros(M, 1);
    Pgm = zeros(Ng, M);

    k = 1;
    while k <= M
        attempts = 0;
        ok = false;

        while ~ok && attempts < opts.maxAttempts
            attempts = attempts + 1;

            mpc = mpc0;

            % 1) Random load scaling
            load_scale = opts.loadScaleMin + (opts.loadScaleMax - opts.loadScaleMin) * rand;
            mpc.bus(:,3) = load_scale * Dem0;
            mpc.bus(:,4) = load_scale * Qdem0;
            Pd = sum(mpc.bus(:,3));

            % 2) Random generation around Pg_base
            gen_pert = opts.genPertMin + (opts.genPertMax - opts.genPertMin) * rand(Ng,1);
            Pg_tent  = Pg_base .* gen_pert;

            % Enforce bounds
            Pg_tent = max(Pg_tent, max(Pmin, opts.minFracPmax * Pmax));
            Pg_tent = min(Pg_tent, opts.pmaxMargin * Pmax);

            % 3) Normalize total generation to Pd*(1+loss_fac)
            target_total = Pd * (1 + loss_fac);
            beta = target_total / sum(Pg_tent);
            Pg = Pg_tent * beta;

            Pg = max(Pg, max(Pmin, opts.minFracPmax * Pmax));
            Pg = min(Pg, opts.pmaxMargin * Pmax);

            mpc.gen(:,2) = Pg;

            % 4) Run PF
            [res, success] = runpf(mpc, mpopt);

            if success
                ok = true;
                PL(k,1)  = sum(res.gen(:,2)) - sum(mpc.bus(:,3));
                Pgm(:,k) = res.gen(:,2);
                fprintf('Training scenario %d converged (attempts=%d).\n', k, attempts);
            end
        end

        if ok
            k = k + 1;
        else
            error('Could not find convergent training scenario for k=%d.', k);
        end
    end

    out = struct();
    out.CaseName = CaseName;
    out.Ng = Ng;
    out.M  = M;
    out.PL = PL;
    out.Pgm = Pgm;
    out.meta.loss_fac = loss_fac;
    out.meta.opts = opts;

    if opts.saveFile
        saveName = sprintf(opts.savePattern, CaseName);
        save(saveName, 'PL', 'Pgm');
        out.saveName = saveName;
        fprintf('Saved training scenarios to: %s\n', saveName);
    else
        out.saveName = '';
    end
end

function opts = set_default_opts(opts, def)
%SET_DEFAULT_OPTS Fill missing fields in opts with defaults.
    fn = fieldnames(def);
    for i = 1:numel(fn)
        if ~isfield(opts, fn{i})
            opts.(fn{i}) = def.(fn{i});
        end
    end
end
