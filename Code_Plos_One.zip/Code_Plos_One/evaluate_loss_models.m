function out = evaluate_loss_models(CaseName, opts)
%EVALUATE_LOSS_MODELS Evaluate trained B models on a test scenario.
%
% Loads:
%   - B_Training_<CaseName>.mat  (B, time)
%   - TestScenario_<CaseName>.mat (PL, Pgm)
%
% Computes PL_hat and error metrics per norm:
%   mean, std, mmse, iqr
% Also returns training time vector.

    if nargin < 2, opts = struct(); end

    % ---- Defaults ----
    def.trainPattern = 'B_Training_%s.mat';
    def.testPattern  = 'TestScenario_%s.mat';
    def.saveFile     = true;
    def.savePattern  = 'Eval_%s.mat';

    opts = set_default_opts(opts, def);

    % Load training coefficients
    fB = sprintf(opts.trainPattern, CaseName);
    assert(isfile(fB), 'File not found: %s', fB);
    SB = load(fB);
    assert(isfield(SB,'B') && isfield(SB,'time'), 'File %s must contain B and time.', fB);

    B = SB.B;
    time = SB.time;

    assert(iscell(B) && numel(B)==12, 'B must be a 12-element cell array.');
    assert(isvector(time) && numel(time)==4, 'time must be [t1 t2 t3 tinf].');

    % Load test scenario
    fT = sprintf(opts.testPattern, CaseName);
    assert(isfile(fT), 'File not found: %s', fT);
    ST = load(fT);
    assert(isfield(ST,'PL') && isfield(ST,'Pgm'), 'File %s must contain PL and Pgm.', fT);

    PL  = ST.PL;
    Pgm = ST.Pgm;

    if isrow(PL), PL = PL.'; end
    M = size(Pgm,2);
    n = size(Pgm,1);
    assert(numel(PL)==M, 'PL must have M elements (M=size(Pgm,2)).');

    normLabels = {'1','2','3','inf'};
    nNorm = 4;

    % Predict for each norm
    PL_hat = zeros(M, nNorm);
    E      = zeros(M, nNorm);

    for iNorm = 1:nNorm
        base = 3*(iNorm-1);
        B00 = B{base+1};
        B10 = B{base+2};
        B20 = B{base+3};

        assert(isscalar(B00), 'B00 must be scalar.');
        assert(isvector(B10) && numel(B10)==n, 'B10 size mismatch.');
        assert(all(size(B20)==[n n]), 'B20 size mismatch.');

        PL_hat(:,iNorm) = quadLoss(Pgm, B20, B10, B00);

        % NOTE: if PL has zeros, handle separately to avoid Inf
        E(:,iNorm) = 100*(PL - PL_hat(:,iNorm))./PL;
    end

    % Metrics per norm
    meanE = mean(E, 1);
    stdE  = std(E, 0, 1);
    mmseE = mean(E.^2, 1);
    iqrE  = iqr(E);

    Tmetrics = table(normLabels.', meanE.', stdE.', mmseE.', iqrE.', time(:), ...
        'VariableNames', {'Norm','MeanErr','StdErr','MMSE','IQR','TrainTime_s'});

    out = struct();
    out.CaseName = CaseName;
    out.normLabels = normLabels;
    out.PL_true = PL;
    out.PL_hat = PL_hat;
    out.E = E;
    out.time = time(:).';
    out.metrics = Tmetrics;
    out.opts = opts;

    if opts.saveFile
        saveName = sprintf(opts.savePattern, CaseName);
        save(saveName, 'Tmetrics', 'E', 'PL_hat', 'PL', 'time', 'normLabels');
        out.saveName = saveName;
        fprintf('Saved evaluation results to: %s\n', saveName);
    else
        out.saveName = '';
    end
end

function y = quadLoss(P, B2, B1, B0)
%QUADLOSS y(k) = p_k' B2 p_k + B1 p_k + B0, with P = [p_1 ... p_M].

    if iscolumn(B1), B1 = B1.'; end
    quadTerm = sum(P .* (B2 * P), 1).';  % (M x 1)
    linTerm  = (B1 * P).';              % (M x 1)
    y = quadTerm + linTerm + B0;
end

function opts = set_default_opts(opts, def)
    fn = fieldnames(def);
    for i = 1:numel(fn)
        if ~isfield(opts, fn{i})
            opts.(fn{i}) = def.(fn{i});
        end
    end
end
