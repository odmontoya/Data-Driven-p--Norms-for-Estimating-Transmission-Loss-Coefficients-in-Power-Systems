% run_pipeline_example.m
% Minimal end-to-end pipeline example for one case.

clc; clear;

Case = 2;
CaseName = get_case_name(Case);

% 1) Generate training scenarios
genTrainOpts = struct();
genTrainOpts.seed = 1234;
genTrainOpts.saveFile = true;
genTrainOpts.savePattern = 'DataTrain_%s.mat';
generate_training_scenarios(CaseName, genTrainOpts);

% 2) Train models (norm 1/2/3/inf)
trainOpts = struct();
trainOpts.solver = 'mosek';
trainOpts.verbose = 1;
trainOpts.saveFile = true;
train_loss_models(CaseName, trainOpts);

% 3) Generate test scenarios (evaluation set)
genTestOpts = struct();
genTestOpts.seed = 2026;
genTestOpts.M = 1000;
genTestOpts.saveFile = true;
genTestOpts.savePattern = 'TestScenario_%s.mat';
generate_test_scenarios(CaseName, genTestOpts);

% 4) Evaluate
evalOpts = struct();
evalOpts.saveFile = true;
evalOpts.savePattern = 'Eval_%s.mat';
outEval = evaluate_loss_models(CaseName, evalOpts);

disp(outEval.metrics);
