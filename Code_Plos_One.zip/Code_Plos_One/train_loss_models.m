function out = train_loss_models(CaseName, opts)
%TRAIN_LOSS_MODELS Train quadratic loss models for norms 1,2,3,inf.
%
% Loads Train_<CaseName>.mat (PL, Pgm), solves YALMIP problems, then saves:
%   B    : 1x12 cell array with coefficients for each norm
%   time : 1x4 vector of training times [t1 t2 t3 tinf]
%
% Requires: YALMIP + solver (default MOSEK)

    if nargin < 2, opts = struct(); end

    % ---- Defaults ----
    def.trainPattern = 'DataTrain_%s.mat';
    def.savePattern  = 'B_Training_%s.mat';
    def.solver       = 'mosek';
    def.verbose      = 1;
    def.Bmin         = 0;
    def.Bmax         = 10;
    def.saveFile     = true;

    opts = set_default_opts(opts, def);

    % Load training data
    trainFile = sprintf(opts.trainPattern, CaseName);
    assert(isfile(trainFile), 'Training file not found: %s', trainFile);
    S = load(trainFile);
    assert(isfield(S,'PL') && isfield(S,'Pgm'), 'File %s must contain PL and Pgm.', trainFile);

    PL  = S.PL;
    Pgm = S.Pgm;

    if isrow(PL), PL = PL.'; end
    G = size(Pgm, 1);
    M = size(Pgm, 2);
    assert(numel(PL) == M, 'PL must have M elements (M = size(Pgm,2)).');

    % Train each norm
    ops = sdpsettings('verbose', opts.verbose, 'solver', opts.solver);

    [B00norm_1,  B10norm_1,  B20norm_1,  time_norm_1]   = solve_one_norm(Pgm, PL, G, M, 1,   opts.Bmin, opts.Bmax, ops, false);
    [B00norm_2,  B10norm_2,  B20norm_2,  time_norm_2]   = solve_one_norm(Pgm, PL, G, M, 2,   opts.Bmin, opts.Bmax, ops, false);
    [B00norm_3,  B10norm_3,  B20norm_3,  time_norm_3]   = solve_one_norm(Pgm, PL, G, M, 3,   opts.Bmin, opts.Bmax, ops, true);   % keeps diag(B20)>=0
    [B00norm_inf,B10norm_inf,B20norm_inf,time_norm_inf] = solve_one_norm(Pgm, PL, G, M, inf, opts.Bmin, opts.Bmax, ops, false);

    % Pack outputs (fixed ordering)
    B = { ...
        B00norm_1,   B10norm_1,   B20norm_1, ...
        B00norm_2,   B10norm_2,   B20norm_2, ...
        B00norm_3,   B10norm_3,   B20norm_3, ...
        B00norm_inf, B10norm_inf, B20norm_inf};

    time = [time_norm_1, time_norm_2, time_norm_3, time_norm_inf];

    out = struct();
    out.CaseName = CaseName;
    out.B = B;
    out.time = time;
    out.normLabels = {'1','2','3','inf'};
    out.opts = opts;

    if opts.saveFile
        saveName = sprintf(opts.savePattern, CaseName);
        save(saveName, 'B', 'time');
        out.saveName = saveName;
        fprintf('Saved trained coefficients to: %s\n', saveName);
    else
        out.saveName = '';
    end
end

function [B00, B10, B20, tsec] = solve_one_norm(Pgm, PL, G, M, pNorm, Bmin, Bmax, ops, addDiagConstraint)
%SOLVE_ONE_NORM Solve one YALMIP model with objective norm(T,pNorm).

    tic
    B20 = sdpvar(G, G, 'symmetric');
    B10 = sdpvar(1, G);
    B00 = sdpvar(1, 1);
    T   = sdpvar(M, 1);

    if addDiagConstraint
        Constraints = [B20 >= 0, diag(B20) >= 0, Bmin <= B00, B00 <= Bmax];
    else
        Constraints = [B20 >= 0, Bmin <= B00, B00 <= Bmax];
    end

    for k = 1:M
        Constraints = [Constraints, ...
            B10 * Pgm(:,k) >= 0, ...
            T(k,1) == PL(k,1) - (Pgm(:,k)' * B20 * Pgm(:,k)) - (B10 * Pgm(:,k)) - B00];
    end

    Obj = norm(T, pNorm);
    sol = optimize(Constraints, Obj, ops);

    tsec = toc;

    assert(sol.problem == 0, ...
        'Optimization failed (norm=%s). YALMIP code: %d', mat2str(pNorm), sol.problem);

    B20 = value(B20);
    B10 = value(B10);
    B00 = value(B00);

    % Clean NaNs (safety)
    B10(isnan(B10)) = 0;
end

function opts = set_default_opts(opts, def)
    fn = fieldnames(def);
    for i = 1:numel(fn)
        if ~isfield(opts, fn{i})
            opts.(fn{i}) = def.(fn{i});
        end
    end
end
